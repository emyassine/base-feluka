---
title: "Pricing & Engagements | Numerimondes"
description: "How Numerimondes structures consulting, development and operational projects."
lang: en
status: "ready-for-review"
---

# Pricing & engagements

## The right commercial model for the mission.

We price work according to its purpose, scope, complexity, delivery risk and required expertise. A useful proposal explains **what you receive**, **what decisions you need to make** and **what the engagement will cost**.

## Initial qualification

An introductory discussion helps us understand the objective and whether Numerimondes could contribute. In-depth analysis, operational audits, research and solution design may form a paid discovery assignment when they require substantive work.

## Common engagement models

### Fixed-scope project

A defined set of deliverables for an agreed price, assumptions and acceptance criteria. Suitable when the requirements are sufficiently clear.

### Discovery or feasibility study

A separately scoped assessment, which may produce process maps, solution options, risk findings, specifications and investment estimates. Any credit against later implementation is offered only when explicitly stated in the proposal.

### Milestone-based delivery

A project organized into approved phases, with scope, payment and acceptance points for each stage. Suitable for larger or evolving initiatives.

### Time-based specialist engagement

Defined consulting, research or engineering capacity over an agreed period, with reporting and limits clearly documented.

### Recurring operations & support

An ongoing arrangement for agreed infrastructure, monitoring, maintenance, improvement or advisory responsibilities. Coverage, response commitments and exclusions are stated in the agreement.

## What shapes the quotation

- The result sought and measurable acceptance criteria.
- The existing environment, data quality and integration needs.
- Required skills, equipment, licensing and third-party services.
- Security, availability, privacy and compliance considerations.
- Delivery location, access needs, support and documentation.
- Dependencies, uncertainty and the requested timeline.

## What every proposal should clarify

Scope, deliverables, ownership and licensing, confidentiality, schedule, pricing, payment terms, customer responsibilities, change management, acceptance and after-delivery support.

We may recommend an existing product, a limited process change or staged implementation where these better serve the business.

## Ask for an estimate

Share the background, desired outcome, current obstacles and target date. A short brief is enough to start a discussion; accurate commitments follow an agreed scope.

**Request a proposal** → `/contact?topic=quote`

<!-- Internal: No public price list or blanket guarantees without approved commercial policy. -->
